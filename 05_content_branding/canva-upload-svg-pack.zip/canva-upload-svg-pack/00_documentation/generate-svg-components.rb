require "fileutils"
require "csv"

ROOT = File.expand_path("..", __dir__)

COLORS = {
  deep_green: "#1C3B34",
  forest_green: "#285447",
  sage: "#5E8D7A",
  cream: "#F2EBDC",
  beige: "#E7DDC8",
  stone: "#C9C5BB",
  anthracite: "#2A2A2A",
  white: "#FFFFFE"
}

MANIFEST = []

def write_svg(folder, filename, label, svg)
  dir = File.join(ROOT, folder)
  FileUtils.mkdir_p(dir)
  File.write(File.join(dir, filename), svg.strip + "\n")
  MANIFEST << [folder, filename, label]
end

def wrap(width, height, body)
  %(<svg xmlns="http://www.w3.org/2000/svg" width="#{width}" height="#{height}" viewBox="0 0 #{width} #{height}" role="img">#{body}</svg>)
end

def text(x, y, value, size, fill, family = "Jost, Arial, sans-serif", weight = "400", anchor = "start")
  %(<text x="#{x}" y="#{y}" fill="#{fill}" font-family="#{family}" font-size="#{size}" font-weight="#{weight}" text-anchor="#{anchor}" letter-spacing="0">#{value}</text>)
end

def broken_circle(cx, cy, r, stroke, width = 3, opacity = 1)
  %(<path d="M #{cx - r * 0.85} #{cy - r * 0.52} A #{r} #{r} 0 0 1 #{cx + r * 0.85} #{cy - r * 0.52}" fill="none" stroke="#{stroke}" stroke-width="#{width}" stroke-linecap="round" opacity="#{opacity}"/><path d="M #{cx - r * 0.85} #{cy + r * 0.52} A #{r} #{r} 0 0 0 #{cx + r * 0.85} #{cy + r * 0.52}" fill="none" stroke="#{stroke}" stroke-width="#{width}" stroke-linecap="round" opacity="#{opacity}"/>)
end

color_rows = [
  ["foret-profond", "Vert principal", COLORS[:deep_green]],
  ["vert-foret", "Vert fonce", COLORS[:forest_green]],
  ["sauge", "Vert clair", COLORS[:sage]],
  ["creme", "Blanc casse", COLORS[:cream]],
  ["beige", "Beige", COLORS[:beige]],
  ["pierre", "Gris pierre", COLORS[:stone]],
  ["anthracite", "Noir doux", COLORS[:anthracite]],
  ["blanc-surface", "Blanc surface", COLORS[:white]]
]

color_rows.each do |slug, label, hex|
  fg = [COLORS[:deep_green], COLORS[:forest_green], COLORS[:anthracite]].include?(hex) ? COLORS[:cream] : COLORS[:deep_green]
  write_svg(
    "04_couleurs",
    "ethny-couleur-#{slug}.svg",
    "Couleur #{label}",
    wrap(1080, 1080, %(<rect width="1080" height="1080" fill="#{hex}"/>#{text(90, 850, label, 64, fg, "Cormorant Garamond, Georgia, serif")}#{text(90, 930, hex, 42, fg)}))
  )
end

swatches = color_rows.each_with_index.map do |(_, label, hex), i|
  x = 90 + (i % 4) * 360
  y = 200 + (i / 4) * 330
  %(<rect x="#{x}" y="#{y}" width="260" height="190" rx="14" fill="#{hex}" stroke="#{COLORS[:stone]}"/><text x="#{x}" y="#{y + 250}" fill="#{COLORS[:deep_green]}" font-family="Jost, Arial, sans-serif" font-size="34">#{label}</text><text x="#{x}" y="#{y + 296}" fill="#{COLORS[:forest_green]}" font-family="Jost, Arial, sans-serif" font-size="28">#{hex}</text>)
end.join

write_svg(
  "04_couleurs",
  "ethny-palette-officielle.svg",
  "Palette officielle complete",
  wrap(1600, 1000, %(<rect width="1600" height="1000" fill="#{COLORS[:cream]}"/>#{text(90, 110, "Palette officielle Ethny", 64, COLORS[:deep_green], "Cormorant Garamond, Georgia, serif")}#{swatches}))
)

write_svg(
  "05_typographies",
  "ethny-typographie-hierarchie.svg",
  "Hierarchie typographique Canva",
  wrap(1600, 2000, %(<rect width="1600" height="2000" fill="#{COLORS[:cream]}"/>#{text(120, 170, "Typographies Ethny", 86, COLORS[:deep_green], "Cormorant Garamond, Georgia, serif")}#{text(120, 300, "H1 - Cormorant Garamond", 78, COLORS[:deep_green], "Cormorant Garamond, Georgia, serif")}#{text(120, 430, "H2 - Cuisine premium, claire et chaleureuse", 58, COLORS[:deep_green], "Cormorant Garamond, Georgia, serif")}#{text(120, 550, "H3 - Experience culinaire sur mesure", 42, COLORS[:forest_green], "Cormorant Garamond, Georgia, serif")}#{text(120, 700, "Sous-titre - Jost Medium", 34, COLORS[:deep_green], "Jost, Arial, sans-serif", "600")}#{text(120, 800, "Texte courant - Jost Regular. Lecture calme, precise et confortable.", 30, COLORS[:anthracite])}<line x1="120" y1="900" x2="1480" y2="900" stroke="#{COLORS[:stone]}"/>#{text(120, 1030, "Regles", 48, COLORS[:deep_green], "Cormorant Garamond, Georgia, serif")}#{text(120, 1120, "Deux familles maximum. Lisibilite mobile obligatoire.", 28, COLORS[:anthracite])}))
)

[
  ["ethny-bg-vert-profond-texture.svg", COLORS[:deep_green], COLORS[:cream], "Fond vert profond"],
  ["ethny-bg-creme-texture.svg", COLORS[:cream], COLORS[:deep_green], "Fond creme"],
  ["ethny-bg-sauge-respiration.svg", "#DDE8E1", COLORS[:deep_green], "Fond sauge doux"],
  ["ethny-bg-pierre-menu.svg", COLORS[:stone], COLORS[:deep_green], "Fond pierre"]
].each do |filename, bg, fg, label|
  dots = 80.times.map { |i| %(<circle cx="#{(i * 137) % 1080}" cy="#{(i * 211) % 1350}" r="#{1 + (i % 3)}" fill="#{fg}"/>) }.join
  write_svg(
    "12_arriere-plans",
    filename,
    label,
    wrap(1080, 1350, %(<rect width="1080" height="1350" fill="#{bg}"/><g opacity="0.07">#{broken_circle(890, 230, 180, fg, 3)}#{broken_circle(190, 1120, 130, fg, 2)}</g><g opacity="0.055">#{dots}</g>))
  )
end

green_lines = 140.times.map { |i| %(<line x1="#{(i * 89) % 1080}" y1="#{(i * 47) % 1080}" x2="#{((i * 89) % 1080) + 80}" y2="#{((i * 47) % 1080) + 8}" stroke="#{COLORS[:cream]}" stroke-width="#{1 + (i % 2)}"/>) }.join
cream_lines = 120.times.map { |i| %(<line x1="#{(i * 71) % 1080}" y1="#{(i * 103) % 1080}" x2="#{((i * 71) % 1080) + 100}" y2="#{((i * 103) % 1080) + 5}" stroke="#{COLORS[:stone]}" stroke-width="1"/>) }.join

write_svg("06_textures", "ethny-texture-papier-vert.svg", "Texture papier vert", wrap(1080, 1080, %(<rect width="1080" height="1080" fill="#{COLORS[:deep_green]}"/><g opacity="0.08">#{green_lines}</g>)))
write_svg("06_textures", "ethny-texture-papier-creme.svg", "Texture papier creme", wrap(1080, 1080, %(<rect width="1080" height="1080" fill="#{COLORS[:cream]}"/><g opacity="0.16">#{cream_lines}</g>)))

write_svg("07_motifs", "ethny-motif-cercle-brise-filigrane.svg", "Motif cercle brise", wrap(1080, 1080, %(<rect width="1080" height="1080" fill="#{COLORS[:cream]}"/><g opacity="0.18">#{broken_circle(540, 540, 360, COLORS[:forest_green], 6)}</g>)))
write_svg("07_motifs", "ethny-motif-vague-filigrane.svg", "Motif vague", wrap(1600, 600, %(<rect width="1600" height="600" fill="#{COLORS[:cream]}"/><path d="M0 320 C240 120 420 520 680 310 C900 130 1080 520 1320 300 C1450 180 1540 180 1600 230" fill="none" stroke="#{COLORS[:forest_green]}" stroke-width="8" stroke-linecap="round" opacity="0.18"/>)))
dots_grid = 12.times.map { |row| 12.times.map { |col| %(<circle cx="#{90 + col * 82}" cy="#{90 + row * 82}" r="2.8" fill="#{COLORS[:cream]}"/>) }.join }.join
write_svg("07_motifs", "ethny-motif-grille-points.svg", "Motif grille points", wrap(1080, 1080, %(<rect width="1080" height="1080" fill="#{COLORS[:deep_green]}"/><g opacity="0.22">#{dots_grid}</g>)))

separator_bodies = [
  %(<line x1="100" y1="100" x2="980" y2="100" stroke="#{COLORS[:forest_green]}" stroke-width="2"/>),
  %(<line x1="100" y1="100" x2="430" y2="100" stroke="#{COLORS[:forest_green]}" stroke-width="2"/><circle cx="540" cy="100" r="8" fill="#{COLORS[:forest_green]}"/><line x1="650" y1="100" x2="980" y2="100" stroke="#{COLORS[:forest_green]}" stroke-width="2"/>),
  %(<path d="M120 100 C300 40 420 160 540 100 C660 40 780 160 960 100" fill="none" stroke="#{COLORS[:forest_green]}" stroke-width="3" stroke-linecap="round"/>),
  %(<line x1="100" y1="80" x2="980" y2="80" stroke="#{COLORS[:stone]}" stroke-width="2"/><line x1="100" y1="120" x2="980" y2="120" stroke="#{COLORS[:stone]}" stroke-width="2"/>)
]
separator_bodies.each_with_index { |body, i| write_svg("08_separateurs", "ethny-separateur-%02d.svg" % (i + 1), "Separateur #{i + 1}", wrap(1080, 200, %(<rect width="1080" height="200" fill="none"/>#{body}))) }

[
  ["ethny-cadre-instagram-1080x1350.svg", 1080, 1350],
  ["ethny-cadre-story-1080x1920.svg", 1080, 1920],
  ["ethny-cadre-carre-1080x1080.svg", 1080, 1080],
  ["ethny-cadre-gbp-1200x628.svg", 1200, 628],
  ["ethny-cadre-menu-a4.svg", 1240, 1754]
].each do |filename, w, h|
  write_svg("09_cadres", filename, "Cadre #{w}x#{h}", wrap(w, h, %(<rect width="#{w}" height="#{h}" fill="none"/><rect x="48" y="48" width="#{w - 96}" height="#{h - 96}" rx="14" fill="none" stroke="#{COLORS[:stone]}" stroke-width="2"/><rect x="72" y="72" width="#{w - 144}" height="#{h - 144}" rx="10" fill="none" stroke="#{COLORS[:forest_green]}" stroke-width="1" opacity="0.35"/>)))
end

[
  ["ethny-badge-nouvelle-identite.svg", "NOUVELLE IDENTITE"],
  ["ethny-badge-meme-exigence.svg", "MEME EXIGENCE"],
  ["ethny-badge-chef-prive.svg", "CHEF PRIVE"],
  ["ethny-badge-sur-mesure.svg", "SUR MESURE"],
  ["ethny-badge-experience.svg", "EXPERIENCE"]
].each do |filename, label|
  write_svg("10_badges", filename, label, wrap(900, 260, %(<rect width="900" height="260" fill="none"/><rect x="60" y="70" width="780" height="120" rx="3" fill="#{COLORS[:deep_green]}"/><text x="450" y="145" fill="#{COLORS[:cream]}" font-family="Jost, Arial, sans-serif" font-size="36" font-weight="600" text-anchor="middle" letter-spacing="2">#{label}</text>)))
end

[
  ["ethny-bouton-demander-proposition.svg", "Demander une proposition"],
  ["ethny-bouton-verifier-disponibilite.svg", "Verifier la disponibilite"],
  ["ethny-bouton-recevoir-devis.svg", "Recevoir un devis personnalise"],
  ["ethny-bouton-decouvrir-site.svg", "Decouvrir le site"]
].each do |filename, label|
  write_svg("11_boutons", filename, label, wrap(900, 260, %(<rect width="900" height="260" fill="none"/><rect x="80" y="70" width="740" height="120" rx="10" fill="#{COLORS[:deep_green]}"/><text x="450" y="145" fill="#{COLORS[:cream]}" font-family="Jost, Arial, sans-serif" font-size="34" font-weight="600" text-anchor="middle">#{label}</text>)))
end

write_svg("13_mockups", "ethny-mockup-post-instagram.svg", "Mockup post Instagram", wrap(1400, 1600, %(<rect width="1400" height="1600" fill="#{COLORS[:cream]}"/><rect x="220" y="120" width="960" height="1200" rx="28" fill="#{COLORS[:deep_green]}"/><rect x="280" y="220" width="840" height="720" rx="14" fill="#{COLORS[:forest_green]}"/><text x="700" y="1060" fill="#{COLORS[:cream]}" font-family="Cormorant Garamond, Georgia, serif" font-size="72" text-anchor="middle">Visuel Ethny</text>)))
write_svg("13_mockups", "ethny-mockup-story.svg", "Mockup story", wrap(1080, 1920, %(<rect width="1080" height="1920" fill="#{COLORS[:deep_green]}"/><rect x="110" y="220" width="860" height="1320" rx="28" fill="#{COLORS[:cream]}"/><text x="540" y="940" fill="#{COLORS[:deep_green]}" font-family="Cormorant Garamond, Georgia, serif" font-size="82" text-anchor="middle">Story</text>)))

CSV.open(File.join(ROOT, "00_documentation", "generated-svg-manifest.csv"), "w") do |csv|
  csv << ["folder", "filename", "label"]
  MANIFEST.each { |row| csv << row }
end
