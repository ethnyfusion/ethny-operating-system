# Pack SVG Canva - Ethny Fusion

Ce dossier est le pack prêt à uploader dans Canva.

Objectif : fournir tous les éléments graphiques de la charte en `.svg`, avec un nommage simple et des dossiers faciles à reproduire dans Canva.

## Règle importante

Les logos et pictogrammes officiels viennent directement de la charte graphique :

- `ethny/branding/logo/`
- `ethny/branding/icons/`

Les autres fichiers SVG sont des composants Canva-safe créés à partir des règles de charte : couleurs, cadres, séparateurs, boutons, badges, fonds, textures et motifs.

Ils ne remplacent jamais le logo ni les pictogrammes officiels.

## Arborescence

```text
canva-upload-svg-pack/
├── 00_documentation
├── 01_logos
├── 02_pictogrammes
├── 03_icones
├── 04_couleurs
├── 05_typographies
├── 06_textures
├── 07_motifs
├── 08_separateurs
├── 09_cadres
├── 10_badges
├── 11_boutons
├── 12_arriere-plans
├── 13_mockups
└── 14_archives
```

## Ordre d'import conseillé dans Canva

1. `01_logos`
2. `02_pictogrammes`
3. `03_icones`
4. `04_couleurs`
5. `05_typographies`
6. `06_textures`
7. `07_motifs`
8. `08_separateurs`
9. `09_cadres`
10. `10_badges`
11. `11_boutons`
12. `12_arriere-plans`
13. `13_mockups`

## Palette utilisée

- Foret profond : `#1C3B34`
- Vert foret : `#285447`
- Sauge : `#5E8D7A`
- Creme : `#F2EBDC`
- Beige : `#E7DDC8`
- Pierre : `#C9C5BB`
- Anthracite : `#2A2A2A`
- Blanc surface : `#FFFFFE`

## Vérification avant usage

Avant d'utiliser un asset dans un modèle Canva :

- vérifier que le logo n'est pas déformé ;
- vérifier que le cercle reste brisé ;
- vérifier que les pictogrammes restent monochromes ;
- ne pas mélanger avec des icônes Canva génériques ;
- garder le vert profond comme couleur héro.
