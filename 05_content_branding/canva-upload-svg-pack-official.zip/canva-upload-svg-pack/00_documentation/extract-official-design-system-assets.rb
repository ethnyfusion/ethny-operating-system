require "fileutils"
require "csv"

ROOT = File.expand_path("..", __dir__)
DS_ROOT = "/Users/reginaldsmit/Desktop/ethny/ethny 2.0 /Graphisme/Logo ( identité visuelle ) /Charte graphique/Ethny Nomad Cuisine Design System"
ICON_SOURCE = File.join(DS_ROOT, "components/icons/Icon.jsx")
LOGO_SOURCE = File.join(DS_ROOT, "assets/logo")

COLORS = {
  deep_green: "#1C3B34",
  forest: "#285447",
  sage: "#5E8D7A",
  cream: "#F2EBDC",
  stone: "#C9C5BB"
}

MANIFEST = []

def write_file(folder, filename, label, source, content)
  dir = File.join(ROOT, folder)
  FileUtils.mkdir_p(dir)
  File.write(File.join(dir, filename), content.strip + "\n")
  MANIFEST << [folder, filename, label, source]
end

def svg(width, height, body, attrs = "")
  %(<svg xmlns="http://www.w3.org/2000/svg" width="#{width}" height="#{height}" viewBox="0 0 #{width} #{height}" #{attrs}>#{body}</svg>)
end

def safe_name(name)
  name.to_s.downcase.gsub(/[^a-z0-9]+/, "-").gsub(/^-|-$/, "")
end

def copy_official_logos
  Dir.glob(File.join(LOGO_SOURCE, "*.svg")).sort.each do |source|
    target = "ethny-official-#{File.basename(source)}"
    FileUtils.cp(source, File.join(ROOT, "01_logos", target))
    MANIFEST << ["01_logos", target, "Official design-system logo", source]
  end
end

def extract_icons
  src = File.read(ICON_SOURCE)
  src.scan(/^\s{2}([a-z0-9_]+):\s*'([^']+)'/).each do |name, inner|
    body = %(<g fill="none" stroke="#{COLORS[:forest]}" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">#{inner}</g>)
    write_file(
      "02_pictogrammes",
      "ethny-picto-#{name}.svg",
      "Official pictogram #{name}",
      ICON_SOURCE,
      svg(24, 24, body, %(role="img" aria-label="ethny pictogram #{name}"))
    )
  end
end

def write_brand_motifs
  motifs = {
    "courbes" => %(<path d="M10 20a14 14 0 0 1 28 0"/><path d="M10 30a14 14 0 0 0 28 0"/>),
    "feuille" => %(<path d="M24 6C10 14 8 30 24 42C40 30 38 14 24 6Z"/><path d="M24 10V38"/>),
    "ramure" => %(<path d="M24 42V18M24 18l-8-10M24 18l8-10M18 26l-6-4M30 26l6-4"/>),
    "rond-brise" => %(<circle cx="24" cy="24" r="15" stroke-dasharray="6 4"/>)
  }

  source = File.join(DS_ROOT, "guidelines/brand/pictogram-motifs.card.html")
  motifs.each do |name, body|
    write_file(
      "07_motifs",
      "ethny-motif-officiel-#{name}.svg",
      "Official brand motif #{name}",
      source,
      svg(48, 48, %(<g fill="none" stroke="#{COLORS[:forest]}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">#{body}</g>), %(role="img" aria-label="ethny motif #{name}"))
    )
  end
end

class Mulberry32
  def initialize(seed)
    @a = seed & 0xffffffff
  end

  def call
    @a = (@a + 0x6D2B79F5) & 0xffffffff
    t = @a
    t = (((t ^ (t >> 15)) * (1 | t)) & 0xffffffff)
    t = (t + (((t ^ (t >> 7)) * (61 | t)) & 0xffffffff)) & 0xffffffff
    ((t ^ (t >> 14)) & 0xffffffff).to_f / 4_294_967_296.0
  end
end

def closed_loop(cx, cy, radius, wobble, n, rot, rng)
  pts = []
  n.times do |i|
    a = rot + (i.to_f / n) * Math::PI * 2
    r = radius + (rng.call - 0.5) * 2 * wobble
    pts << [cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.82]
  end
  d = "M #{pts[0][0].round(1)} #{pts[0][1].round(1)} "
  n.times do |i|
    p0 = pts[(i - 1 + n) % n]
    p1 = pts[i]
    p2 = pts[(i + 1) % n]
    p3 = pts[(i + 2) % n]
    c1x = p1[0] + (p2[0] - p0[0]) / 6.0
    c1y = p1[1] + (p2[1] - p0[1]) / 6.0
    c2x = p2[0] - (p3[0] - p1[0]) / 6.0
    c2y = p2[1] - (p3[1] - p1[1]) / 6.0
    d += "C #{c1x.round(1)} #{c1y.round(1)} #{c2x.round(1)} #{c2y.round(1)} #{p2[0].round(1)} #{p2[1].round(1)} "
  end
  d + "Z"
end

def contour_cluster(cx, cy, rings, base_r, gap, wobble, rng)
  out = []
  rot = rng.call * Math::PI
  rings.times do |i|
    out << closed_loop(cx, cy, base_r + i * gap, wobble * (1 - i.to_f / (rings * 2)), 9, rot + i * 0.05, rng)
  end
  out
end

def wave(y, amp, freq, phase, width)
  d = "M -20 #{y.round(1)} "
  x = 0
  while x <= width + 20
    yy = y + Math.sin((x.to_f / width) * Math::PI * 2 * freq + phase) * amp
    d += "L #{x} #{yy.round(1)} "
    x += 40
  end
  d
end

def graticule(width, height, warp, spacing)
  out = []
  x = spacing
  while x < width
    d = "M #{x} -20 "
    y = -20
    while y <= height + 20
      xx = x + Math.sin((y.to_f / height) * Math::PI * 3 + x) * warp
      d += "L #{xx.round(1)} #{y} "
      y += 40
    end
    out << d
    x += spacing
  end
  y = spacing
  while y < height
    d = "M -20 #{y} "
    x2 = -20
    while x2 <= width + 20
      yy = y + Math.sin((x2.to_f / width) * Math::PI * 3 + y) * warp
      d += "L #{x2} #{yy.round(1)} "
      x2 += 40
    end
    out << d
    y += spacing
  end
  out
end

def veins(cx, cy, len, branches, rng)
  out = []
  out << "M #{cx} #{cy + len / 2} C #{cx - 12} #{cy + len / 4} #{cx + 12} #{cy - len / 4} #{cx} #{cy - len / 2}"
  branches.times do |i|
    t = (i + 1).to_f / (branches + 1)
    y = cy + len / 2 - t * len
    side = i.odd? ? 1 : -1
    bl = (0.28 + rng.call * 0.22) * len * (1 - t * 0.4)
    out << "M #{cx} #{y.round(1)} Q #{(cx + side * bl * 0.5).round(1)} #{(y - bl * 0.4).round(1)} #{(cx + side * bl).round(1)} #{(y - bl * 0.7).round(1)}"
  end
  out
end

def stroke_group(paths, color, opacity, width)
  %(<g fill="none" stroke="#{color}" opacity="#{opacity}" stroke-width="#{width}" stroke-linecap="round" stroke-linejoin="round">#{paths.map { |d| %(<path d="#{d}"/>) }.join}</g>)
end

def build_signature_variant(variant, seed = 7, color = COLORS[:cream])
  w = 1600
  h = 900
  rng = Mulberry32.new(seed)
  layers = +""
  case variant
  when "exploration"
    waves = []
    7.times { |i| waves << wave(120 + i * 105, 16 + rng.call * 10, 1.3 + rng.call * 0.5, rng.call * 6, w) }
    wind = []
    5.times { |i| wind << wave(200 + i * 150, 5, 2.4, rng.call * 6, w) }
    layers << stroke_group(graticule(w, h, 10, 260), color, 0.05, 1)
    layers << stroke_group(waves, color, 0.08, 1.4)
    layers << stroke_group(wind, color, 0.03, 0.8)
    layers << stroke_group(contour_cluster(1230, 250, 5, 60, 26, 20, rng), color, 0.05, 1)
  when "topographie"
    c = []
    [[380, 300], [1120, 560], [820, 180], [1350, 300]].each_with_index do |(x, y), i|
      c += contour_cluster(x, y, 6 + (i % 2), 46 + i * 8, 30, 26, rng)
    end
    layers << stroke_group(graticule(w, h, 8, 300), color, 0.03, 0.8)
    layers << stroke_group(c, color, 0.07, 1.2)
  when "vegetal"
    v = []
    [[300, 480], [900, 260], [1300, 620], [640, 720]].each do |x, y|
      v += veins(x, y, 300 + rng.call * 120, 5, rng)
    end
    fine = []
    6.times { |i| fine << wave(140 + i * 130, 8, 1.1, rng.call * 6, w) }
    layers << stroke_group(fine, color, 0.03, 0.8)
    layers << stroke_group(v, color, 0.07, 1.1)
  when "geometrie"
    g = []
    x = -200
    while x < w
      g << "M #{x} 0 L #{x + h} #{h}"
      x += 130
    end
    x = 0
    while x < w + 200
      g << "M #{x} 0 L #{x - h} #{h}"
      x += 130
    end
    dots = []
    y = 130
    while y < h
      x = 130
      while x < w
        dots << closed_loop(x, y, 4, 0, 8, 0, rng)
        x += 130
      end
      y += 130
    end
    layers << stroke_group(g, color, 0.03, 0.8)
    layers << stroke_group(dots, color, 0.06, 1)
  else
    lines = []
    4.times { |i| lines << wave(220 + i * 170, 10, 0.8, rng.call * 6, w) }
    layers << stroke_group(lines, color, 0.05, 1)
  end
  svg(w, h, layers, %(preserveAspectRatio="xMidYMid slice" role="img" aria-label="ethny signature field #{variant}"))
end

def write_signature_fields
  source = File.join(DS_ROOT, "ui_kits/website/Textures.jsx")
  %w[exploration topographie vegetal geometrie minimal].each do |variant|
    motif = build_signature_variant(variant, 7, COLORS[:cream])
    write_file("06_textures", "ethny-texture-officielle-#{variant}-cream-on-transparent.svg", "Official texture #{variant}", source, motif)
    body = %(<rect width="1600" height="900" fill="#{COLORS[:deep_green]}"/>#{motif.sub(/\A<svg[^>]*>/, "").sub(%r{</svg>\z}, "")})
    write_file("12_arriere-plans", "ethny-bg-officiel-#{variant}-vert-profond.svg", "Official background #{variant}", source, svg(1600, 900, body, %(role="img" aria-label="ethny official background #{variant}")))
  end
end

def write_contour_field
  paths = 6.times.map do |i|
    y = 60 + i * 55
    %(<path d="M -40 #{y} Q 200 #{10 + i * 55} 400 #{y} T 840 #{y}" fill="none" stroke="rgba(40,84,71,0.14)" stroke-width="1.2"/>)
  end.join
  source = File.join(DS_ROOT, "ui_kits/website/Motifs.jsx")
  write_file("07_motifs", "ethny-motif-officiel-contour-field.svg", "Official ContourField motif", source, svg(800, 400, paths, %(preserveAspectRatio="none" role="img" aria-label="ethny official contour field")))
end

copy_official_logos
extract_icons
write_brand_motifs
write_signature_fields
write_contour_field

CSV.open(File.join(ROOT, "00_documentation", "official-design-system-manifest.csv"), "w") do |csv|
  csv << ["folder", "filename", "label", "source"]
  MANIFEST.each { |row| csv << row }
end
